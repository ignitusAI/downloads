# audio-emotion-recognition
TF JS implementation of in browser audio speech recognition

Setup, start http server in this base directory first:

1. Open index.html in browser by visiting 'http://localhost:8000/'
2. Give microphone permission
3. Monitor output in console.log, predicting output for happy+excited state

Emotions: - IEMOCAP: [happy + excited, sad, angry, neutral]
